<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sa23726932";
$port = 3306; // Ensure this matches your MySQL configuration

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
