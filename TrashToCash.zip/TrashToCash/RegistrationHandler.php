<?php
	if(isset($_POST["btnSubmit"])) {
		
		$name = $_POST["txtName"];
		$email = $_POST["txtEmail"];
		$password = $_POST["txtPassword"];
		$contact = $_POST["txtContactNo"];
		
		$con = mysqli_connect("localhost","root","","sa23726932","3306");
		if(!$con) {
			die("Sorry, we can not connect with the DB.");
		} else {
			echo "DB is connected successfully.";
		}
	}	
	
?>